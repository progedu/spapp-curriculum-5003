// Copyright© DWANGO Co.,Ltd. All Rights Reserved.
/*:
 # プロトコル
 `ExampleProtocol`
 */



/*:
 ## プロトコルを継承する
 `SimpleClass`
 */



//: `SimpleClass2` と　`ExampleProtocol` の配列



//: [Previous](@previous) | [Next](@next)
