// Copyright© DWANGO Co.,Ltd. All Rights Reserved.
/*:
 # クラスと初期化関数
 `Shape` クラス
 */



//: `Shape` クラスの初期化をし、メソッドを呼んでみましょう。



//: `NamedShape` クラス



//: `NamedShape` クラスを初期化しましょう。



//: `Square` クラス



//: `Circle` クラス



//: `Triangle` クラスと `shapesArray`



/*:
 > `as?` を `as!` にするとどうなるでしょう？
 */

//: [Previous](@previous) | [Next](@next)
