// Copyright© DWANGO Co.,Ltd. All Rights Reserved.
/*:
 # 関数
 `greet` 関数
 */



//: 関数を呼び出してみましょう。



//: メソッドを呼んでみましょう。



//: [Previous](@previous)
