/*:
 # 制御フロー
 ## 条件文
 基本的な if 文
 */



/*:
 > `number` の値を変化させて何が出力されるか見てみましょう。
 */

//: Optional Binding



/*:
 > `optionalName` を `nil` にするとどうなるでしょう？
 */

//: 複数条件の if 文



//: switch 文



/*:
 > `default` ケースを取り除くとどうなるでしょう？
 */

//: ## ループ



//: CountableRange



//: CountableClosedRange



//: [Previous](@previous) | [Next](@next)
