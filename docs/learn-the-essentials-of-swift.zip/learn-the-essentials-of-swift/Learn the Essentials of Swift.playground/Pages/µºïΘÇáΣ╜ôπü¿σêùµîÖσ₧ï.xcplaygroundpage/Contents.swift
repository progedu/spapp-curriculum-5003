/*:
 # 列挙型と構造体
 ## 列挙型
 `Rank`
 */



//: `rawValue` を指定した初期化



//: `Suit`



/*:
 ## 構造体
 `Card`
 */



//: [Previous](@previous) | [Next](@next)
